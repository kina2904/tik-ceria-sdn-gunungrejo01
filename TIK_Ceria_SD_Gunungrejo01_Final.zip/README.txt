TIK CERIA – MEDIA PEMBELAJARAN TIK SDN GUNUNGREJO 01

Nama: Zakinah Mawadda
Kampus: Universitas Muhammadiyah Bone
Perwakilan: KKN MAS Kelompok 67
Sasaran: Siswa-siswi Kelas 3 SDN Gunungrejo 01

Fitur: Materi TIK, video pembelajaran, kuis 10 soal, nilai otomatis, mode terang/gelap, dan identitas/logo KKN MAS.

Cara menjalankan:
1. Ekstrak ZIP.
2. Buka index.html.
3. Masukkan video MP4 ke folder video dengan nama pembelajaran-tik.mp4.
