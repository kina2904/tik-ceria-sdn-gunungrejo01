Masukkan gambar materi TIK di folder ini.
